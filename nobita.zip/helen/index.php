<?php
// List of target .txt files
$files = ['file1.txt', 'file2.txt', 'file3.txt', 'file4.txt'];

// Register shutdown function
register_shutdown_function(function() use ($files) {
    foreach ($files as $file) {
        $randomText = generateRandomText(20); // 20 characters
        file_put_contents($file, $randomText . PHP_EOL, FILE_APPEND);
    }
});

// Function to generate random text
function generateRandomText($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $text = '';
    for ($i = 0; $i < $length; $i++) {
        $text .= $characters[random_int(0, strlen($characters) - 1)];
    }
    return $text;
}

// Just to demonstrate script running
echo "Script is running. It will write to files on shutdown.\n";
